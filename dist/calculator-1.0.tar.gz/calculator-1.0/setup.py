from setuptools import setup, find_packages


setup(name='calculator',
      version='1.0',
      packages=find_packages(exclude=['contrib', 'docs', 'tests']),
      author='Phinxk',
      author_email='juan.gomez.q@gmail.com',
      url='https://github.com/Juan7/small-package',
      )
